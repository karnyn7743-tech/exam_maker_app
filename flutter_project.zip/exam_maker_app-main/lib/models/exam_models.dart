import 'dart:convert';

/// نمط الاختبار العام في التطبيق
enum ExamType {
  traditional, // الاختبارات الشاملة (التحريرية التقليدية)
  automated,   // اختبارات الأتمتة الذكية (نماذج التظليل OMR)
}

/// نمط رموز خيارات أسئلة الاختيار من متعدد
enum ChoiceSymbolType {
  arabicLetters, // أ ، ب ، جـ ، د
  numbers,       // ١ ، ٢ ، ٣ ، ٤
}

enum QuestionTitleOrientation {
  horizontal,
  verticalBottomToTop,
  verticalTopToBottom,
}

/// اتجاه كتابة النص في عمود الدرجة
enum GradeTextOrientation {
  horizontal,          // أفقي عادي
  verticalBottomToTop, // عمودي مائل للأعلى
  verticalTopToBottom, // عمودي مائل للأسفل
}

/// أنواع العناصر القابلة للإدراج داخل الأسئلة
enum ElementType {
  image,
  textBox,
  dottedLine,
  mathOperation,
  table, // الجداول المخصصة القابلة للتحرير والتلوين
  shape, // الأشكال الهندسية والتلقائية الملونة
}

class InsertableElement {
  final String id;
  final ElementType type;
  String content;
  double width;
  double height;
  String alignment;
  double dx;          // الإزاحة الأفقية للتحريك الحر
  double dy;          // الإزاحة الرأسية للتحريك الحر
  bool isFloating;    // هل العنصر عائم بحرية كبرنامج Word

  InsertableElement({
    required this.id,
    required this.type,
    required this.content,
    this.width = 100,
    this.height = 100,
    this.alignment = 'center',
    this.dx = 0.0,
    this.dy = 0.0,
    this.isFloating = false,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'type': type.name,
        'content': content,
        'width': width,
        'height': height,
        'alignment': alignment,
        'dx': dx,
        'dy': dy,
        'isFloating': isFloating,
      };

  factory InsertableElement.fromMap(Map<String, dynamic> map) {
    final rawType = map['type']?.toString() ?? 'textBox';
    final parsedType = ElementType.values.firstWhere(
      (e) => e.name == rawType,
      orElse: () => ElementType.textBox,
    );

    return InsertableElement(
      id: map['id'] ?? '',
      type: parsedType,
      content: map['content'] ?? '',
      width: (map['width'] as num?)?.toDouble() ?? 100.0,
      height: (map['height'] as num?)?.toDouble() ?? 100.0,
      alignment: map['alignment'] ?? 'center',
      dx: (map['dx'] as num?)?.toDouble() ?? 0.0,
      dy: (map['dy'] as num?)?.toDouble() ?? 0.0,
      isFloating: map['isFloating'] ?? false,
    );
  }
}

class TextSpanModel {
  String text;
  bool isBold;
  bool isUnderline;
  double fontSize;
  String fontFamily;
  String colorHex; // دعم تلوين الكلمات والنصوص بصيغة HEX

  TextSpanModel({
    required this.text,
    this.isBold = false,
    this.isUnderline = false,
    this.fontSize = 14.0,
    this.fontFamily = 'Traditional Arabic',
    this.colorHex = '#000000',
  });

  Map<String, dynamic> toMap() => {
        'text': text,
        'isBold': isBold,
        'isUnderline': isUnderline,
        'fontSize': fontSize,
        'fontFamily': fontFamily,
        'colorHex': colorHex,
      };

  factory TextSpanModel.fromMap(Map<String, dynamic> map) => TextSpanModel(
        text: map['text'] ?? '',
        isBold: map['isBold'] ?? false,
        isUnderline: map['isUnderline'] ?? false,
        fontSize: (map['fontSize'] as num?)?.toDouble() ?? 14.0,
        fontFamily: map['fontFamily'] ?? 'Traditional Arabic',
        colorHex: map['colorHex'] ?? '#000000',
      );
}

class QuestionModel {
  final String id;
  String title;
  QuestionTitleOrientation titleOrientation;
  double mark;
  GradeTextOrientation gradeOrientation; // اتجاه كتابة الدرجة في عمود الدرجة
  List<TextSpanModel> spans;
  List<InsertableElement> elements;
  String answerKey;
  bool isTwoColumns;

  QuestionModel({
    required this.id,
    required this.title,
    this.titleOrientation = QuestionTitleOrientation.horizontal,
    this.mark = 0.0,
    this.gradeOrientation = GradeTextOrientation.horizontal,
    required this.spans,
    List<InsertableElement>? elements,
    this.answerKey = '',
    this.isTwoColumns = false,
  }) : elements = elements ?? [];

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'titleOrientation': titleOrientation.name,
        'mark': mark,
        'gradeOrientation': gradeOrientation.name,
        'spans': spans.map((s) => s.toMap()).toList(),
        'elements': elements.map((e) => e.toMap()).toList(),
        'answerKey': answerKey,
        'isTwoColumns': isTwoColumns,
      };

  factory QuestionModel.fromMap(Map<String, dynamic> map) {
    final rawOrientation = map['titleOrientation']?.toString() ?? 'horizontal';
    final parsedOrientation = QuestionTitleOrientation.values.firstWhere(
      (e) => e.name == rawOrientation,
      orElse: () => QuestionTitleOrientation.horizontal,
    );

    final rawGradeOrient = map['gradeOrientation']?.toString() ?? 'horizontal';
    final parsedGradeOrient = GradeTextOrientation.values.firstWhere(
      (e) => e.name == rawGradeOrient,
      orElse: () => GradeTextOrientation.horizontal,
    );

    return QuestionModel(
      id: map['id'] ?? '',
      title: map['title'] ?? '',
      titleOrientation: parsedOrientation,
      mark: (map['mark'] as num?)?.toDouble() ?? 0.0,
      gradeOrientation: parsedGradeOrient,
      spans: (map['spans'] as List<dynamic>?)
              ?.map((item) => TextSpanModel.fromMap(item))
              .toList() ??
          [],
      elements: (map['elements'] as List<dynamic>?)
              ?.map((item) => InsertableElement.fromMap(item))
              .toList() ??
          [],
      answerKey: map['answerKey'] ?? '',
      isTwoColumns: map['isTwoColumns'] ?? false,
    );
  }
}

class HeaderModel {
  String country;
  String ministry;
  String governorate;
  String directorate;
  String school;
  String basmalaText;
  String? logoImagePath;
  String grade;
  String subject;
  String examDate;
  String examTime;
  String period;
  String examTitle;
  String instructionText;
  bool isMultiPage;
  String singlePageFooterText;
  String continuationText;
  String teacherSignature;
  bool topMargin1cm;

  // خصائص استيراد بيانات الطلاب وكود المادة
  String studentDataMode; // 'none', 'namesOnly', 'namesAndQr'
  String? excelFilePath;
  int subjectCode;

  // خصائص الخطوط وتنسيقات حقول الترويسة
  String basmalaFont;
  double basmalaFontSize;
  bool basmalaBold;

  String titleFont;
  double titleFontSize;
  bool titleBold;

  String adminFont;
  double adminFontSize;
  bool adminBold;

  String detailsFont;
  double detailsFontSize;
  bool detailsBold;

  HeaderModel({
    this.country = 'الجمهورية اليمنية',
    this.ministry = 'وزارة التربية والتعليم والبحث العلمي',
    this.governorate = 'مكتب التربية والتعليم بمحافظة ذمار',
    this.directorate = 'مكتب التربية والتعليم بمديرية عتمة',
    this.school = 'مدرسة هجرة بني عبد الصمد',
    this.basmalaText = 'بسم الله الرحمن الرحيم',
    this.logoImagePath,
    this.grade = 'التاسع',
    this.subject = 'الرياضيات',
    this.examDate = '1447/08/15 هـ',
    this.examTime = 'ساعتان',
    this.period = 'واحدة',
    this.examTitle = 'اختبار نهاية الفصل الدراسي الأول',
    this.instructionText = 'أجب عن جميع الأسئلة الآتية',
    this.isMultiPage = false,
    this.singlePageFooterText = 'انتهت الأسئلة مع تمنياتنا لكم بالتوفيق والنجاح',
    this.continuationText = 'يتبع الصفحة التالية ◄',
    this.teacherSignature = 'معلم المادة: ......................',
    this.topMargin1cm = true,
    this.studentDataMode = 'none',
    this.excelFilePath,
    this.subjectCode = 1,
    this.basmalaFont = 'Amiri',
    this.basmalaFontSize = 12.0,
    this.basmalaBold = true,
    this.titleFont = 'Amiri',
    this.titleFontSize = 12.0,
    this.titleBold = true,
    this.adminFont = 'Amiri',
    this.adminFontSize = 9.5,
    this.adminBold = false,
    this.detailsFont = 'Amiri',
    this.detailsFontSize = 10.0,
    this.detailsBold = false,
  });

  Map<String, dynamic> toMap() => {
        'country': country,
        'ministry': ministry,
        'governorate': governorate,
        'directorate': directorate,
        'school': school,
        'basmalaText': basmalaText,
        'logoImagePath': logoImagePath,
        'grade': grade,
        'subject': subject,
        'examDate': examDate,
        'examTime': examTime,
        'period': period,
        'examTitle': examTitle,
        'instructionText': instructionText,
        'isMultiPage': isMultiPage,
        'singlePageFooterText': singlePageFooterText,
        'continuationText': continuationText,
        'teacherSignature': teacherSignature,
        'topMargin1cm': topMargin1cm,
        'studentDataMode': studentDataMode,
        'excelFilePath': excelFilePath,
        'subjectCode': subjectCode,
        'basmalaFont': basmalaFont,
        'basmalaFontSize': basmalaFontSize,
        'basmalaBold': basmalaBold,
        'titleFont': titleFont,
        'titleFontSize': titleFontSize,
        'titleBold': titleBold,
        'adminFont': adminFont,
        'adminFontSize': adminFontSize,
        'adminBold': adminBold,
        'detailsFont': detailsFont,
        'detailsFontSize': detailsFontSize,
        'detailsBold': detailsBold,
      };

  factory HeaderModel.fromMap(Map<String, dynamic> map) => HeaderModel(
        country: map['country'] ?? 'الجمهورية اليمنية',
        ministry: map['ministry'] ?? 'وزارة التربية والتعليم والبحث العلمي',
        governorate: map['governorate'] ?? '',
        directorate: map['directorate'] ?? '',
        school: map['school'] ?? '',
        basmalaText: map['basmalaText'] ?? 'بسم الله الرحمن الرحيم',
        logoImagePath: map['logoImagePath'],
        grade: map['grade'] ?? '',
        subject: map['subject'] ?? '',
        examDate: map['examDate'] ?? '',
        examTime: map['examTime'] ?? '',
        period: map['period'] ?? '',
        examTitle: map['examTitle'] ?? '',
        instructionText: map['instructionText'] ?? '',
        isMultiPage: map['isMultiPage'] ?? false,
        singlePageFooterText: map['singlePageFooterText'] ?? '',
        continuationText: map['continuationText'] ?? '',
        teacherSignature: map['teacherSignature'] ?? '',
        topMargin1cm: map['topMargin1cm'] ?? true,
        studentDataMode: map['studentDataMode'] ?? 'none',
        excelFilePath: map['excelFilePath'],
        subjectCode: map['subjectCode'] ?? 1,
        basmalaFont: map['basmalaFont'] ?? 'Amiri',
        basmalaFontSize: (map['basmalaFontSize'] as num?)?.toDouble() ?? 12.0,
        basmalaBold: map['basmalaBold'] ?? true,
        titleFont: map['titleFont'] ?? 'Amiri',
        titleFontSize: (map['titleFontSize'] as num?)?.toDouble() ?? 12.0,
        titleBold: map['titleBold'] ?? true,
        adminFont: map['adminFont'] ?? 'Amiri',
        adminFontSize: (map['adminFontSize'] as num?)?.toDouble() ?? 9.5,
        adminBold: map['adminBold'] ?? false,
        detailsFont: map['detailsFont'] ?? 'Amiri',
        detailsFontSize: (map['detailsFontSize'] as num?)?.toDouble() ?? 10.0,
        detailsBold: map['detailsBold'] ?? false,
      );
}

/// إعدادات أسئلة وورقة إجابة الأتمتة الذكية (OMR)
class AutomatedExamConfig {
  int trueFalseCount;
  int mcqCount;
  ChoiceSymbolType choiceSymbolType;

  AutomatedExamConfig({
    this.trueFalseCount = 10,
    this.mcqCount = 10,
    this.choiceSymbolType = ChoiceSymbolType.arabicLetters,
  });

  Map<String, dynamic> toMap() => {
        'trueFalseCount': trueFalseCount,
        'mcqCount': mcqCount,
        'choiceSymbolType': choiceSymbolType.name,
      };

  factory AutomatedExamConfig.fromMap(Map<String, dynamic> map) {
    final rawSymbolType = map['choiceSymbolType']?.toString() ?? 'arabicLetters';
    final parsedSymbolType = ChoiceSymbolType.values.firstWhere(
      (e) => e.name == rawSymbolType,
      orElse: () => ChoiceSymbolType.arabicLetters,
    );

    return AutomatedExamConfig(
      trueFalseCount: map['trueFalseCount'] ?? 10,
      mcqCount: map['mcqCount'] ?? 10,
      choiceSymbolType: parsedSymbolType,
    );
  }
}

class ExamModel {
  final String id;
  String fileName;
  ExamType examType;
  AutomatedExamConfig automatedConfig;
  DateTime createdAt;
  DateTime updatedAt;
  HeaderModel header;
  List<QuestionModel> questions;
  double targetTotalMarks; // الدرجة المستهدفة لميزان تدقيق الدرجات التراكمي

  ExamModel({
    required this.id,
    required this.fileName,
    this.examType = ExamType.traditional,
    AutomatedExamConfig? automatedConfig,
    required this.createdAt,
    required this.updatedAt,
    required this.header,
    required this.questions,
    this.targetTotalMarks = 50.0,
  }) : automatedConfig = automatedConfig ?? AutomatedExamConfig();

  double get totalMarks =>
      questions.fold(0.0, (sum, item) => sum + item.mark);

  ExamModel copyWith({
    String? newId,
    String? newFileName,
    ExamType? newExamType,
    AutomatedExamConfig? newAutomatedConfig,
    HeaderModel? newHeader,
    List<QuestionModel>? newQuestions,
    double? newTargetTotalMarks,
  }) {
    return ExamModel(
      id: newId ?? id,
      fileName: newFileName ?? fileName,
      examType: newExamType ?? examType,
      automatedConfig: newAutomatedConfig ??
          AutomatedExamConfig.fromMap(automatedConfig.toMap()),
      createdAt: createdAt,
      updatedAt: DateTime.now(),
      header: newHeader ?? HeaderModel.fromMap(header.toMap()),
      questions: newQuestions ??
          questions.map((q) => QuestionModel.fromMap(q.toMap())).toList(),
      targetTotalMarks: newTargetTotalMarks ?? targetTotalMarks,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'fileName': fileName,
        'examType': examType.name,
        'automatedConfig': automatedConfig.toMap(),
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'header': header.toMap(),
        'questions': questions.map((q) => q.toMap()).toList(),
        'targetTotalMarks': targetTotalMarks,
      };

  factory ExamModel.fromMap(Map<String, dynamic> map) {
    final rawType = map['examType']?.toString() ?? 'traditional';
    final parsedType = ExamType.values.firstWhere(
      (e) => e.name == rawType,
      orElse: () => ExamType.traditional,
    );

    return ExamModel(
      id: map['id'] ?? '',
      fileName: map['fileName'] ?? '',
      examType: parsedType,
      automatedConfig: AutomatedExamConfig.fromMap(
        map['automatedConfig'] ?? {},
      ),
      createdAt: map['createdAt'] != null
          ? DateTime.parse(map['createdAt'])
          : DateTime.now(),
      updatedAt: map['updatedAt'] != null
          ? DateTime.parse(map['updatedAt'])
          : DateTime.now(),
      header: HeaderModel.fromMap(map['header'] ?? {}),
      questions: (map['questions'] as List<dynamic>?)
              ?.map((item) => QuestionModel.fromMap(item))
              .toList() ??
          [],
      targetTotalMarks: (map['targetTotalMarks'] as num?)?.toDouble() ?? 50.0,
    );
  }

  String toJson() => jsonEncode(toMap());
  factory ExamModel.fromJson(String source) =>
      ExamModel.fromMap(jsonDecode(source));
}
